import datetime

from rest_framework import serializers
from .models import (BestGame, OutdatedGame, NewGame)

class BestGamesAPISerializer(serializers.ModelSerializer):
    us_release_date = serializers.DateField(required=False)
    eu_release_date = serializers.DateField(required=False)
    class Meta:
        model = BestGame
        fields = (
            'id', 'game_title', 'developer',
            'us_publisher', 'us_release_date',
            'eu_publisher', 'eu_release_date'
            )

        read_only_fields = ('user',)

    def validate(self, data):
        from django.core.exceptions import ValidationError
        
        us_pulisher = data.get('us_publisher', None)
        us_release_date = data.get('us_release_date', None)
        eu_publisher = data.get('eu_publisher', None)
        eu_release_date = data.get('eu_release_date', None)
        
        if (us_pulisher == 'Unreleased' or not us_pulisher) and us_release_date:
            raise ValidationError("Game not released in USA yet.")
        if (eu_publisher == 'Unreleased' or not eu_publisher) and eu_release_date:
            raise ValidationError("Game not released in USA yet.")
        return data


class OutdatedGamesAPISerializer(serializers.ModelSerializer):
    class Meta:
        model = OutdatedGame
        fields = ('id', 'game_title', 'developer',
                  'publisher', 'cancellation_date')

        read_only_fields = ('user',)

    def validate(self, data):
        from django.core.exceptions import ValidationError

        cancellation_date = data.get('cancellation_date', None)
        min_year = 1970*365
        today = datetime.date.today()
        if cancellation_date.day < min_year:
            raise ValidationError("This Game isn't outdated.")
        if cancellation_date.day > today.day:
            raise ValidationError(f"Date can't be greater than {today}.")
        return data


class NewGamesAPISerializer(serializers.ModelSerializer):
    class Meta:
        model = NewGame
        fields = ('id', 'game_title', 'publisher', 'released_year')

        read_only_fields = ('user',)
    
    def validate(self, data):
        from django.core.exceptions import ValidationError

        today = datetime.date.today()
        released_year = data.get('released_year', None)
        if released_year < 1985:
            raise ValidationError("This Game isn't new.")
        if released_year*365 > today.day:
            raise ValidationError(f"Date can't be greater than {today}.")
        return data

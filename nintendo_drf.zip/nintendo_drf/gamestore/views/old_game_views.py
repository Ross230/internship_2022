from django.shortcuts import render
from django.db.models import Q

from rest_framework import generics, permissions

from gamestore.models import OutdatedGame
from gamestore.serializers import OutdatedGamesAPISerializer

from gamestore.permissions import IsOwnerOrReadOnly
# Create your views here.

class OutdatedGamesListAPIViews(generics.ListCreateAPIView):
    serializer_class = OutdatedGamesAPISerializer
    permission_class = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        queryset_list = OutdatedGame.objects.filter(id__gte=0)
        query = self.request.GET.get('q')
        if query:
            queryset_list = queryset_list.filter(
                Q(game_title__icontains=query)|
                Q(developer__icontains=query)|
                Q(publisher__icontains=query)|
                Q(cancellation_date__icontains=query))
        return queryset_list

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class OutdatedGamesDetailAPIViews(generics.RetrieveUpdateDestroyAPIView):
    queryset = OutdatedGame.objects.filter(id__gte=0)
    serializer_class = OutdatedGamesAPISerializer
    permission_class = [IsOwnerOrReadOnly]
    lookup_field = 'id'

    def perform_update(self, serializer):
        serializer.save()

    def perform_destroy(self, serializer):
        serializer.delete()

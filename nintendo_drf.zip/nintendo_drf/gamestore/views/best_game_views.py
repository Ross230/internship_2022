from django.shortcuts import render
from django.db.models import Q

from rest_framework import generics, permissions

from gamestore.models import BestGame
from gamestore.serializers import BestGamesAPISerializer

from gamestore.permissions import IsOwnerOrReadOnly
# Create your views here.

class BestGamesListAPIViews(generics.ListCreateAPIView):
    serializer_class = BestGamesAPISerializer
    permission_class = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        queryset_list = BestGame.objects.filter(id__gte=0)
        query = self.request.GET.get('q')
        if query:
            queryset_list = queryset_list.filter(
                Q(game_title__icontains=query)|
                Q(developer__icontains=query)|
                Q(eu_publisher__icontains=query)|
                Q(us_publisher__icontains=query))
        return queryset_list

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class BestGamesDetailAPIViews(generics.RetrieveUpdateDestroyAPIView):
    queryset = BestGame.objects.filter(id__gte=0)
    serializer_class = BestGamesAPISerializer
    permission_class = [IsOwnerOrReadOnly]
    lookup_field = 'id'

    def perform_update(self, serializer):
        serializer.save()

    def perform_destroy(self, serializer):
        serializer.delete()

from django.contrib import admin

from .models import BestGame, OutdatedGame, NewGame
# Register your models here.

admin.site.register(BestGame)
admin.site.register(OutdatedGame)
admin.site.register(NewGame)

import datetime

from django.db import models

from nintendo_drf.users.models import User
# Create your models here.

class BestGame(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    game_title = models.CharField(max_length=70)
    developer = models.CharField(max_length=50)
    us_publisher = models.CharField(max_length=50, default='Unreleased')
    eu_publisher = models.CharField(max_length=50, default='Unreleased')
    us_release_date = models.DateField(null=True)
    eu_release_date = models.DateField(null=True)

    def clean(self):
        from django.core.exceptions import ValidationError

        if (self.us_publisher == 'Unreleased' or not self.us_publisher) and self.us_release_date:
            raise ValidationError("Game not released in USA yet.")
        if (self.eu_publisher == 'Unreleased' or not self.eu_publisher) and self.eu_release_date:
            raise ValidationError("Game not released in Europe yet.")
        super(BestGame, self).clean()

    def __str__(self):
        return self.game_title


class OutdatedGame(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    game_title = models.CharField(max_length=70)
    developer = models.CharField(max_length=50)
    publisher = models.CharField(max_length=50)
    cancellation_date = models.DateField()

    def __str__(self):
        return self.game_title

    def clean(self):
        from django.core.exceptions import ValidationError

        min_year = 1970*365
        today = datetime.date.today()
        if self.cancellation_date.day < min_year:
            raise ValidationError("This Game isn't outdated.")
        super(OutdatedGame, self).clean()


class NewGame(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    game_title = models.CharField(max_length=70)
    publisher = models.CharField(max_length=50)
    released_year = models.PositiveIntegerField()

    def __str__(self):
        return self.game_title

    def clean(self):
        from django.core.exceptions import ValidationError

        today = datetime.date.today()
        if self.released_year < 1985:
            raise ValidationError("This Game isn't new.")
        if self.released_year*365 > today.day:
            raise ValidationError(f"Date can't be greater than {today}.")
        super(NewGame, self).clean()

from django.urls import path

from .views.best_game_views import (
    BestGamesListAPIViews,
    BestGamesDetailAPIViews,
)
from .views.old_game_views import (
    OutdatedGamesListAPIViews,
    OutdatedGamesDetailAPIViews,
)
from .views.new_game_views import (
    NewGamesGamesListAPIViews,
    NewGamesDetailAPIViews
)
app_name = "games"
urlpatterns = [
    path("best/", BestGamesListAPIViews.as_view(), name="best-list"),
    path("best/<int:id>/", BestGamesDetailAPIViews.as_view(), name="best-detail"),
    path("old/", OutdatedGamesListAPIViews.as_view(), name="old-list"),
    path("old/<int:id>/", OutdatedGamesDetailAPIViews.as_view(), name="old-detail"),
    path("new/", NewGamesGamesListAPIViews.as_view(), name="new-list"),
    path("new/<int:id>/", NewGamesDetailAPIViews.as_view(), name="new-detail"),
]
